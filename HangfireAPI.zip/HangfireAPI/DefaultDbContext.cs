﻿using Microsoft.EntityFrameworkCore;

namespace HangfireAPI
{
    public class DefaultDbContext : DbContext
    {
        public DefaultDbContext(DbContextOptions<DefaultDbContext> options)
            : base(options) { }
    }
}
